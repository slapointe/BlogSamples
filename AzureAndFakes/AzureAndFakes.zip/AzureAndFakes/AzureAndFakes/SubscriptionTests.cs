﻿using System;
using System.Linq;
using FluentAssertions;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Microsoft.QualityTools.Testing.Fakes;
using Microsoft.WindowsAzure.Subscriptions;
using Microsoft.WindowsAzure.Subscriptions.Models;
using System.Threading.Tasks;
using Microsoft.WindowsAzure;

namespace AzureAndFakes
{
    [TestClass]
    public class SubscriptionTests
    {
        [TestMethod]
        [TestCategory("Azure")]
        [TestCategory("With Fakes")]
        public void ThisWillNotPerformAnHttpRequestToAzure()
        {
            using (var context = ShimsContext.Create())
            {
                // Arrange:
                var fakeSubscriptionId = new Guid("14201e53-1921-4a12-a1f0-c95735706f7a");
                var fakeRequestId = new Guid("6a1c1756-fa31-49a5-8c24-f013214692ae");
                ISubscriptionOperations subscriptions = new Microsoft.WindowsAzure.Subscriptions.Fakes.StubISubscriptionOperations
                {
                    ListAsyncCancellationToken = (cancelationToken) =>
                        Task.FromResult(new SubscriptionListOperationResponse
                        {
                            RequestId = fakeRequestId.ToString(),
                            StatusCode = System.Net.HttpStatusCode.OK,
                            Subscriptions = new[] {
                                new SubscriptionListOperationResponse.Subscription {
                                        SubscriptionId = fakeSubscriptionId.ToString(),
                                        SubscriptionName = "Fake subscription",
                                        SubscriptionStatus = SubscriptionStatus.Active
                                }
                            }
                        }
                    )
                };
                Microsoft.WindowsAzure.Subscriptions.Fakes.ShimSubscriptionClient.AllInstances.SubscriptionsGet = (subscriptionClient) => subscriptions;

                // Act:
                var results = CloudContext.Clients
                    .CreateSubscriptionClient(new AnonymousCloudCredentials())
                    .Subscriptions
                    .List();
                
                // Assert:
                results.RequestId.Should().Be(fakeRequestId.ToString());
                results.StatusCode.Should().Be(System.Net.HttpStatusCode.OK);
                results.Subscriptions.Should().HaveCount(1);
            }
        }
    }
}
